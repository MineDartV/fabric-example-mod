package com.example.javamod01;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_1268;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_3965;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;

public class BlockPlacementHandler {
    private static final Logger LOGGER = ModLogger.LOGGER;

    private static class_304 PLACE_AIR_KEY;
    private static class_304 PLACE_BELOW_KEY;
    private static boolean placeOnAir = false;
    private static boolean placeBelow = false;
    private static long lastAirPlacement = 0;
    private static final int AIR_PLACEMENT_COOLDOWN = 50; // 50ms cooldown between placements
    private static class_310 client;

    private static boolean placeBlock(class_2338 pos, class_2350 side) {
        if (client.field_1724 == null || client.field_1687 == null) {
            return false;
        }

        try {
            // Get the block state and ensure we can place
            class_2680 state = client.field_1687.method_8320(pos);
            if (!state.method_26215() || client.field_1724.method_6047().method_7960()) {
                LOGGER.debug("Cannot place block at {}: either not air or no item in hand", pos);
                return false;
            }

            // Create a block hit result
            class_243 hitPos = class_243.method_24954(pos);
            class_3965 hitResult = new class_3965(
                hitPos,
                side,
                pos,
                false
            );

            // Try to place the block
            client.field_1761.method_2896(
                client.field_1724,
                class_1268.field_5808,
                hitResult
            );

            // Verify placement immediately
            class_2680 placedState = client.field_1687.method_8320(pos);
            if (!placedState.method_26215()) {
                // Confirm with server
                client.field_1761.method_2902(pos, side);
                return true;
            }

            return false;
        } catch (Exception e) {
            LOGGER.error("Error placing block at {}: {}", pos, e.getMessage());
            return false;
        }
    }

    public static boolean isPlaceOnAir() {
        return placeOnAir;
    }

    public static boolean isPlaceBelow() {
        return placeBelow;
    }

    public static void init() {
        PLACE_AIR_KEY = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.javamod01.place.air",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_N,
            "category.javamod01"
        ));

        PLACE_BELOW_KEY = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.javamod01.place.below",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_M,
            "category.javamod01"
        ));

        client = class_310.method_1551();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1755 == null && client.field_1724 != null && client.field_1687 != null) {
                // Handle key presses
                if (PLACE_AIR_KEY.method_1436()) {
                    placeOnAir = !placeOnAir;
                    client.field_1724.method_7353(class_2561.method_30163("Place on air: " + placeOnAir), false);
                }
                if (PLACE_BELOW_KEY.method_1436()) {
                    placeBelow = !placeBelow;
                    client.field_1724.method_7353(class_2561.method_30163("Place below: " + placeBelow), false);
                }
                
                // Handle air placement when enabled
                if (placeOnAir) {
                    handleAirPlacement();
                }
                
                // Handle below placement
                if (placeBelow) {
                    handleBelowPlacement();
                }
            }
        });

        // Initialize key bindings
        PLACE_AIR_KEY.method_23481(false);
        PLACE_BELOW_KEY.method_23481(false);
    }

    public static void handleAirPlacement() {
        if (client.field_1724 == null || client.field_1687 == null) {
            return;
        }

        try {
            // Check cooldown
            long currentTime = System.currentTimeMillis();
            if (currentTime - lastAirPlacement < AIR_PLACEMENT_COOLDOWN) {
                LOGGER.debug("Cooldown not ready yet");
                return;
            }

            // Get player position and look vector
            class_243 playerPos = client.field_1724.method_19538();
            class_243 lookVec = client.field_1724.method_5720();
            
            // Calculate maximum reach distance (4.5 blocks)
            double reachDistance = 4.5;
            class_243 targetPos = playerPos.method_1019(lookVec.method_1021(reachDistance));
            class_2338 targetBlockPos = new class_2338((int)targetPos.field_1352, (int)targetPos.field_1351, (int)targetPos.field_1350);
            
            // Calculate distance to target
            double distanceToTarget = playerPos.method_1022(targetPos);
            if (distanceToTarget > reachDistance) {
                LOGGER.debug("Target too far away: {} > {}", distanceToTarget, reachDistance);
                return;
            }
            
            // Debug logging
            LOGGER.debug("Attempting to place block at: {}", targetBlockPos);
            LOGGER.debug("Player position: {}", playerPos);
            LOGGER.debug("Look vector: {}", lookVec);
            LOGGER.debug("Distance to target: {}", distanceToTarget);

            // Try to place the block
            if (placeBlock(targetBlockPos, class_2350.field_11036)) {
                LOGGER.debug("Successfully placed block at: {}", targetBlockPos);
                lastAirPlacement = currentTime;
            } else {
                LOGGER.warn("Failed to place block at: {}", targetBlockPos);
            }
        } catch (Exception e) {
            LOGGER.error("Error in air placement: {}", e.getMessage());
            e.printStackTrace();
        }
    }

    public static void handleBelowPlacement() {
        if (client.field_1724 == null || client.field_1687 == null) return;
        
        try {
            // Get the block below the player
            class_2338 targetBlockPos = client.field_1724.method_24515().method_10074();
            class_2680 targetState = client.field_1687.method_8320(targetBlockPos);
            
            // Only place if it's air and we're not in spectator mode
            if (targetState.method_26215() && !client.field_1724.method_7325()) {
                // Check if player is holding a block
                class_1799 heldItem = client.field_1724.method_6047();
                if (heldItem.method_7960() || !(heldItem.method_7909() instanceof class_1747)) {
                    LOGGER.debug("No block item in hand");
                    return;
                }

                // Create a proper block hit result
                class_243 hitPos = class_243.method_24954(targetBlockPos);
                class_3965 hitResult = new class_3965(
                    hitPos,
                    class_2350.field_11036,
                    targetBlockPos,
                    false
                );

                // Try to place the block
                client.field_1761.method_2896(
                    client.field_1724, 
                    class_1268.field_5808, 
                    hitResult
                );
            }
        } catch (Exception e) {
            LOGGER.error("Error in below placement: {}", e.getMessage());
            e.printStackTrace();
        }
    }

    public static boolean canPlaceAt(net.minecraft.class_1937 world, net.minecraft.class_2338 pos) {
        if (world == null) {
            LOGGER.warn("World is null!");
            return false;
        }

        class_2680 blockState = world.method_8320(pos);
        return blockState.method_26215();
    }

    public static class_310 getClient() {
        return client;
    }
}
