package com.example.javamod01;

import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.slf4j.Logger;

public class PreviewState {
    private static final Logger LOGGER = ModLogger.LOGGER;
    private static class_2338 previewPos = null;
    private static class_2680 previewState = null;
    private static boolean previewing = false;
    private static long lastRightClick = 0;
    private static final long COOLDOWN = 100L; // 100ms cooldown

    public static void setPreviewPos(class_2338 pos) {
        previewPos = pos;
    }

    public static class_2338 getPreviewPos() {
        return previewPos;
    }

    public static void setPreviewState(class_2680 state) {
        previewState = state;
    }

    public static class_2680 getPreviewState() {
        return previewState;
    }

    public static void setPreviewing(boolean previewing) {
        PreviewState.previewing = previewing;
    }

    public static boolean isPreviewing() {
        return previewing;
    }

    public static void setLastRightClick(long time) {
        lastRightClick = time;
    }

    public static long getLastRightClick() {
        return lastRightClick;
    }

    public static long getCOOLDOWN() {
        return COOLDOWN;
    }
}
