package com.example.autoblockmod;

import net.minecraft.class_2561;
import net.minecraft.class_310;

public class AutoBlockConfig {
    private static boolean placeOnAir = false;
    private static boolean isEnabled = true;
    private static boolean placeBelow = false;

    public static void init() {
        // Initialize default values
    }

    public static boolean isPlaceOnAir() {
        return placeOnAir;
    }

    public static void setPlaceOnAir(boolean placeOnAir) {
        AutoBlockConfig.placeOnAir = placeOnAir;
        class_2561 message = class_2561.method_30163("AutoBlock: Place on air " + (placeOnAir ? "enabled" : "disabled"));
        if (class_310.method_1551() != null && class_310.method_1551().field_1705 != null) {
            class_310.method_1551().field_1705.method_1743().method_1812(message);
        }
    }

    public static boolean isEnabled() {
        return isEnabled;
    }

    public static void setEnabled(boolean enabled) {
        isEnabled = enabled;
        class_2561 message = class_2561.method_30163("AutoBlock: " + (enabled ? "enabled" : "disabled"));
        if (class_310.method_1551() != null && class_310.method_1551().field_1705 != null) {
            class_310.method_1551().field_1705.method_1743().method_1812(message);
        }
    }

    public static boolean isPlaceBelow() {
        return placeBelow;
    }

    public static void setPlaceBelow(boolean placeBelow) {
        AutoBlockConfig.placeBelow = placeBelow;
        class_2561 message = class_2561.method_30163("AutoBlock: Place below " + (placeBelow ? "enabled" : "disabled"));
        if (class_310.method_1551() != null && class_310.method_1551().field_1705 != null) {
            class_310.method_1551().field_1705.method_1743().method_1812(message);
        }
    }
}
