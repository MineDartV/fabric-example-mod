package com.example.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.example.autoblockmod.AutoBlockConfig;
import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_746;

@Mixin(class_746.class)
public class AutoPlaceMixin {
    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        class_746 player = (class_746) (Object) this;
        class_310 client = class_310.method_1551();
        
        // Only auto-place if mod is enabled
        if (!AutoBlockConfig.isEnabled()) return;
        
        // Only auto-place if place below is enabled
        if (!AutoBlockConfig.isPlaceBelow()) return;
        
        // Only auto-place if player is holding a block item
        if (player.method_6047().method_7960()) return;

        // Place block below player
        class_2338 targetPos = player.method_24515().method_10074();
        class_3965 hitResult = new class_3965(
            player.method_19538().method_1031(0, -1, 0),
            class_2350.field_11036,
            targetPos,
            false
        );
        
        // Try to place the block
        player.method_6104(class_1268.field_5808);
        client.field_1761.method_2896(player, class_1268.field_5808, hitResult);
    }
}
