package com.example.mixin.client;

import net.minecraft.class_636;

public class MixinClasses {
    public static final Class<?>[] CLIENT_PLAYER_INTERACTION_MANAGER = {class_636.class};
}
