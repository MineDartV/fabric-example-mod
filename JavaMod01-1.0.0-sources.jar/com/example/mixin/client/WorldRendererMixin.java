package com.example.mixin.client;

import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_765;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public class WorldRendererMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void renderPreviewBlock(class_4587 matrices, float tickDelta, long limitTime, boolean renderBlockOutline, class_4184 camera, class_757 gameRenderer, class_765 lightmapTextureManager, CallbackInfo ci) {
        PreviewBlockRenderer.renderPreviewBlock(matrices, class_310.method_1551().method_22940().method_23000(), tickDelta);
    }
}
