package com.example.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.example.javamod01.BlockPlacementHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_746;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Mixin(class_746.class)
public class ClientPlayerEntityMixin {
    private static final Logger LOGGER = LoggerFactory.getLogger("javamod01");

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        class_310 client = BlockPlacementHandler.getClient();
        LOGGER.debug("Starting tick with client: {}", client);
        
        if (client.field_1755 == null) {
            LOGGER.debug("No screen is open, checking block placement modes");
            LOGGER.debug("Place on air: {}", BlockPlacementHandler.isPlaceOnAir());
            LOGGER.debug("Place below: {}", BlockPlacementHandler.isPlaceBelow());
            
            if (BlockPlacementHandler.isPlaceOnAir()) {
                LOGGER.debug("Air placement mode is active");
                long window = client.method_22683().method_4490();
                boolean rightClickPressed = GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
                LOGGER.debug("Right click pressed: {}", rightClickPressed);
                
                if (rightClickPressed) {
                    class_1799 stack = client.field_1724.method_6047();
                    LOGGER.debug("Main hand stack: {}", stack);
                    
                    if (stack.method_7960() || !(stack.method_7909() instanceof class_1747)) {
                        LOGGER.debug("No block in hand or invalid item");
                        return;
                    }

                    class_243 hitPos = client.field_1724.method_19538().method_1031(0, 1.5, 0);
                    double range = 5.0;
                    class_243 lookVec = client.field_1724.method_5828(1.0f);
                    
                    LOGGER.debug("Looking for air block in range {} with position {} and direction {}", range, hitPos, lookVec);
                    
                    class_2338 targetPos = null;
                    for (double d = 0.0; d <= range; d += 0.1) {
                        class_243 pos = hitPos.method_1031(lookVec.field_1352 * d, lookVec.field_1351 * d, lookVec.field_1350 * d);
                        class_2338 blockPos = new class_2338((int)pos.field_1352, (int)pos.field_1351, (int)pos.field_1350);
                        
                        LOGGER.debug("Checking position {}", blockPos);
                        boolean isAir = client.field_1724.method_37908().method_8320(blockPos).method_26215();
                        LOGGER.debug("Position {} is air: {}", blockPos, isAir);
                        
                        if (isAir) {
                            targetPos = blockPos;
                            break;
                        }
                    }
                    
                    if (targetPos != null) {
                        LOGGER.info("Found air position: {}", targetPos);
                        class_3965 hitResult = new class_3965(new class_243(targetPos.method_10263() + 0.5, targetPos.method_10264() + 0.5, targetPos.method_10260() + 0.5), class_2350.field_11036, targetPos, false);
                        
                        LOGGER.debug("Creating hit result: {}", hitResult);
                        client.field_1724.method_6104(class_1268.field_5808);
                        LOGGER.debug("Swung hand");
                        
                        try {
                            LOGGER.debug("Attempting to place block at {}", targetPos);
                            // Use client.interactionManager directly
                            client.field_1761.method_2896(client.field_1724, class_1268.field_5808, hitResult);
                            LOGGER.info("Attempted to place block at {}", targetPos);
                        } catch (Exception e) {
                            LOGGER.error("Failed to place block", e);
                        }
                    } else {
                        LOGGER.debug("No air position found in range");
                    }
                }
            }
            
            if (BlockPlacementHandler.isPlaceBelow()) {
                LOGGER.debug("Below placement mode is active");
                class_1799 stack = client.field_1724.method_6047();
                LOGGER.debug("Main hand stack: {}", stack);
                
                if (stack.method_7960() || !(stack.method_7909() instanceof class_1747)) {
                    LOGGER.debug("No block in hand or invalid item");
                    return;
                }

                class_2338 playerPos = client.field_1724.method_24515();
                class_2338 belowPos = playerPos.method_10074();
                
                LOGGER.debug("Checking below position: {}", belowPos);
                
                if (client.field_1724.method_37908().method_8320(belowPos).method_26215()) {
                    LOGGER.info("Found air below player");
                    class_3965 hitResult = new class_3965(new class_243(belowPos.method_10263() + 0.5, belowPos.method_10264() + 0.5, belowPos.method_10260() + 0.5), class_2350.field_11036, belowPos, false);
                    
                    LOGGER.debug("Creating hit result: {}", hitResult);
                    client.field_1724.method_6104(class_1268.field_5808);
                    LOGGER.debug("Swung hand");
                    
                    try {
                        LOGGER.debug("Attempting to place block below player at {}", belowPos);
                        // Use client.interactionManager directly
                        client.field_1761.method_2896(client.field_1724, class_1268.field_5808, hitResult);
                        LOGGER.info("Attempted to place block below player at {}", belowPos);
                    } catch (Exception e) {
                        LOGGER.error("Failed to place block below player", e);
                    }
                } else {
                    LOGGER.debug("Position below player is not air");
                }
            }
        }
    }
}
