package com.example.mixin.client;

import net.minecraft.class_2338;
import net.minecraft.class_2680;

public interface PlayerPreview {
    class_2338 getPreviewPos();
    class_2680 getPreviewState();
    boolean isPreviewing();
}
