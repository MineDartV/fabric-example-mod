package com.example.mixin.client;

import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class PreviewState {
    private static long lastRightClick = 0;
    private static final int COOLDOWN = 200;
    private static class_2338 previewPos = null;
    private static class_2680 previewState = null;
    private static boolean isPreviewing = false;

    public static long getLastRightClick() {
        return lastRightClick;
    }

    public static void setLastRightClick(long lastRightClick) {
        PreviewState.lastRightClick = lastRightClick;
    }

    public static int getCOOLDOWN() {
        return COOLDOWN;
    }

    public static class_2338 getPreviewPos() {
        return previewPos;
    }

    public static void setPreviewPos(class_2338 previewPos) {
        PreviewState.previewPos = previewPos;
    }

    public static class_2680 getPreviewState() {
        return previewState;
    }

    public static void setPreviewState(class_2680 previewState) {
        PreviewState.previewState = previewState;
    }

    public static boolean isPreviewing() {
        return isPreviewing;
    }

    public static void setPreviewing(boolean previewing) {
        PreviewState.isPreviewing = previewing;
    }
}
