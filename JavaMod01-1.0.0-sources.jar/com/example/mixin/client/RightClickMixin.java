package com.example.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.lwjgl.glfw.GLFW;
import com.example.javamod01.BlockPlacementHandler;
import net.minecraft.class_310;
import net.minecraft.class_3675;

@Mixin(class_310.class)
public class RightClickMixin {
    @Inject(method = "handleInputEvents", at = @At("HEAD"))
    private void onHandleInputEvents(CallbackInfo ci) {
        if (BlockPlacementHandler.isPlaceOnAir() && 
            class_3675.method_15987(class_310.method_1551().method_22683().method_4490(), GLFW.GLFW_MOUSE_BUTTON_2)) {
            BlockPlacementHandler.handleAirPlacement();
        }
    }
}
