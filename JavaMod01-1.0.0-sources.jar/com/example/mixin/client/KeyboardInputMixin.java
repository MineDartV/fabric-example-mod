package com.example.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.example.autoblockmod.AutoBlockConfig;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_743;

@Mixin(class_743.class)
public class KeyboardInputMixin {
    private static long lastToggleTime = 0;
    private static final int TOGGLE_DELAY = 200; // 200ms delay between toggles

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        
        if (client.field_1755 == null) {
            long currentTime = System.currentTimeMillis();
            
            // Toggle place on air with N key
            if (class_3675.method_15987(client.method_22683().method_4490(), 'N')) {
                if (currentTime - lastToggleTime > TOGGLE_DELAY) {
                    AutoBlockConfig.setPlaceOnAir(!AutoBlockConfig.isPlaceOnAir());
                    lastToggleTime = currentTime;
                }
            }

            // Toggle place below with M key
            if (class_3675.method_15987(client.method_22683().method_4490(), 'M')) {
                if (currentTime - lastToggleTime > TOGGLE_DELAY) {
                    AutoBlockConfig.setPlaceBelow(!AutoBlockConfig.isPlaceBelow());
                    lastToggleTime = currentTime;
                }
            }
        }
    }
}
