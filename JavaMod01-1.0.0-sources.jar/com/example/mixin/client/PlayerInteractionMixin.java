package com.example.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.example.autoblockmod.AutoBlockConfig;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_746;

@Mixin(class_746.class)
public class PlayerInteractionMixin {
    private static long lastRightClick = 0;
    private static final int COOLDOWN = 200;
    private static boolean isPlacing = false;

    @Inject(method = "swingHand", at = @At("HEAD"))
    private void onSwingHand(class_1268 hand, CallbackInfo ci) {
        if (hand == class_1268.field_5808 && AutoBlockConfig.isEnabled() && AutoBlockConfig.isPlaceOnAir() && !isPlacing) {
            class_310 client = class_310.method_1551();
            class_746 player = (class_746) (Object) this;

            if (client.field_1755 == null) {
                long currentTime = System.currentTimeMillis();
                
                // Only process if cooldown has passed
                if (currentTime - lastRightClick < COOLDOWN) {
                    return;
                }

                // Only place if player is holding a block
                if (player.method_6047().method_7960()) {
                    return;
                }

                // Calculate the position to place the block
                class_243 playerPos = player.method_19538();
                class_243 lookVec = player.method_5720();
                class_243 hitPos = playerPos.method_1019(lookVec.method_1021(5)); // Extend 5 blocks in front of the player
                class_2338 targetPos = new class_2338((int)hitPos.field_1352, (int)hitPos.field_1351, (int)hitPos.field_1350);

                // Get the item stack and world
                class_1799 stack = player.method_6047();
                class_1937 world = player.method_37908();

                // Place the block directly in the world
                if (world != null && stack != null) {
                    isPlacing = true;
                    class_2248 block = class_2248.method_9503(stack.method_7909());
                    class_2680 state = block.method_9564();
                    world.method_8501(targetPos, state);
                    isPlacing = false;
                }

                // Update last right click time
                lastRightClick = currentTime;
            }
        }
    }
}
