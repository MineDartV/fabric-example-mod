package com.example.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import com.example.autoblockmod.AutoBlockConfig;
import org.slf4j.Logger;
import com.example.javamod01.ModLogger;
import net.minecraft.class_1268;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_636;
import net.minecraft.class_746;
import com.example.javamod01.BlockPlacementHandler;

@Mixin(value = class_636.class, remap = true)
public class ClientPlayerInteractionManagerMixin {
    private static final Logger LOGGER = ModLogger.LOGGER;
    private static long lastRightClick = 0;
    private static final int COOLDOWN = 200;

    @Inject(method = "interactBlock", at = @At("HEAD"), cancellable = true)
    private void onInteractBlock(class_746 player, class_1268 hand, class_3965 hitResult, CallbackInfoReturnable<class_3965> cir) {
        LOGGER.info("onInteractBlock called with hand: {}", hand);
        cir.setReturnValue(hitResult);
        cir.cancel();
        class_310 client = class_310.method_1551();
        LOGGER.info("MinecraftClient instance: {}", client);
        
        if (client.field_1755 == null && BlockPlacementHandler.isPlaceOnAir()) {
            LOGGER.info("Place on air enabled: {}", BlockPlacementHandler.isPlaceOnAir());
            long currentTime = System.currentTimeMillis();
            
            // Only process if cooldown has passed
            if (currentTime - lastRightClick < COOLDOWN) {
                LOGGER.info("Cooldown not passed: {}ms remaining", COOLDOWN - (currentTime - lastRightClick));
                return;
            }

            // Only process right click (button 1)
            if (hand != class_1268.field_5808) {
                LOGGER.info("Non-main hand click ignored");
                return;
            }

            // Only place if player is holding a block
            if (client.field_1724.method_6047().method_7960()) {
                LOGGER.info("No item in main hand");
                return;
            }

            // Check if we can place here
            if (!BlockPlacementHandler.canPlaceAt(client.field_1724.method_37908(), hitResult.method_17777())) {
                LOGGER.info("Cannot place at target block");
                return;
            }

            // Place the block
            LOGGER.info("Placing block at position: {}", hitResult.method_17777());
            client.field_1761.method_2896(client.field_1724, class_1268.field_5808, hitResult);
            lastRightClick = currentTime;
            cir.setReturnValue(hitResult);
            cir.cancel();
        }
    }
}
