package com.example.mixin.client;

import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_776;

public class PreviewBlockRenderer {
    public static void renderPreviewBlock(class_4587 matrices, class_4597 vertexConsumers, float tickDelta) {
        if (!PreviewState.isPreviewing()) return;

        class_776 renderManager = class_310.method_1551().method_1541();
        class_2680 state = PreviewState.getPreviewState();
        class_2338 pos = PreviewState.getPreviewPos();
        
        if (state != null && pos != null) {
            matrices.method_22903();
            matrices.method_46416(pos.method_10263(), pos.method_10264(), pos.method_10260());
            matrices.method_22904(0.5, 0.5, 0.5);
            matrices.method_22905(1.01f, 1.01f, 1.01f);
            matrices.method_22904(-0.5, -0.5, -0.5);
            
            renderManager.method_3355(state, pos, class_310.method_1551().field_1687, matrices, vertexConsumers.getBuffer(class_1921.method_23577()), true, null);
            
            matrices.method_22909();
        }
    }
}
